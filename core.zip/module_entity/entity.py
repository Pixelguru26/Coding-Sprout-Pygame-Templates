# Must not import anything from this module. This is a root class.
import math
import pygame.image
import pygame.transform
import core.graphics as graphics
import core.util
import core.geometry as geo

class entity:
  collisionTypes = {
    "circle": "circle",
    "aabb": "aabb",
    "line": "line"
  }
  # Entity type used to distinguish subclasses
  type = "entity"

  # Required initialization for any entity instance
  # team defines which other entities it will interact with
  # x, y indicate the position of the entity from the top left corner (0,0) to the bottom right (w, h)
  #   When the collisionType is circle, this is the center coordinate.
  #   When the collisionType is aabb, this is the top left coordinate.
  #   When the collisionType is line, this is the coordinate of the first point.
  # angle is the visual rotation of this entity, in degrees. Note that it does not affect physics whatsoever.
  # scale is the visual scale factor of the entity. It does not affect physical collision boundaries.
  # collisionType defines what style of calculations will be used to determine intersection with other entities. Can be any of:
  #   "circle": a is read as radius, (x, y) is read as center.
  #   "aabb": non-rotating rectangle. (x, y) is read as top left. a and b are read as width and height, respectively.
  #   "line": line segment. (x, y) is read as the initial point, (a, b) is read as the end point.
  # a, b: dynamic arguments. Meaning is determined by collisionType.
  def __init__(this, team = "none", x = 0, y = 0, angle = 0, scale = 1, collisionType = "circle", a = 0, b = 0):
    this.team = team
    this.x = x
    this.y = y
    this.angle = angle
    this.last_angle = angle
    this.scale = scale
    this.last_scale = scale
    this.speed = 100
    # Each collision type has its own dimension argument overload.
    this.collisionType = collisionType
    if collisionType == "circle":
      this.radius = a
    elif collisionType == "aabb":
      this.w = a
      this.h = b
    elif collisionType == "line":
      this.x2 = a
      this.y2 = b
    this.alive = True
    # Source surface for sprites
    this.sprite = None
    # Cache for storing current rotated and scaled sprite
    this.sprite_cache = None
    this.update_graphics(True)
  
  # This performs no ai functions, but is necessary for proper optimization and visual behavior.
  def update(this, dt):
    this.update_graphics()
  
  # Update cached sprite when rotated or scaled.
  # Only updates when necessary.
  # Provide "True" as a second argument to force an update even if unnecessary.
  def update_graphics(this, override = False):
    doUpdate = False
    # Always necessary
    if this.sprite == None:
      doUpdate = True
      this.sprite = pygame.image.load(core.GAME_DIR+f"/assets/image/error.png")
    if override or this.sprite != this.last_sprite:
      doUpdate = True
      this.last_sprite = this.sprite
    # Automatically update cache for rotations
    if override or this.angle != this.last_angle:
      doUpdate = True
      # Updating cached trig values (future optimization)
      angle = this.angle/180 * math.pi
      this.cos = math.cos(angle)
      this.sin = math.sin(angle)
      this.last_angle = this.angle
    # Automatically update cache for scaling
    if override or this.scale != this.last_scale:
      doUpdate = True
      this.last_scale = this.scale

    # If any property has changed, update sprite cache appropriately.
    # Also fires if the sprite cache is still uninitialized.
    if doUpdate or this.sprite_cache == None:
      # Update cached graphics
      this.sprite_cache = pygame.transform.rotozoom(this.sprite, -this.angle, this.scale)
  
  # Renders cached graphics by default. Does not update cache.
  def draw(this):
    if this.collisionType == "circle":
      graphics.blit_centered(this.sprite_cache, this.x, this.y)
    else:
      graphics.blit(this.sprite_cache, this.x, this.y)

  # Checks if this entity intersects another using proper collision types.
  # Includes exact contact (distance = 0)
  # Returns False if collision types are unimplemented.
  def intersects(this, other):
    if this.collisionType == "circle":
      if other.collisionType == "circle":
        return geo.intersect_circle(this.x, this.y, this.radius, other.x, other.y, other.radius)
      if other.collisionType == "aabb":
        return geo.intersect_aabb_circle(other.x, other.y, other.w, other.h, this.x, this.y, this.radius)
      if other.collisionType == "line":
        return geo.intersect_circle_line(this.x, this.y, this.radius, other.x, other.y, other.x2, other.y2)
    if this.collisionType == "aabb":
      if other.collisionType == "circle":
        return geo.intersect_aabb_circle(this.x, this.y, this.w, this.h, other.x, other.y, other.radius)
      if other.collisionType == "aabb":
        return geo.intersect_aabb(this.x, this.y, this.w, this.h, other.x, other.y, other.w, other.h)
      if other.collisionType == "line":
        return geo.intersect_aabb_line(this.x, this.y, this.w, this.h, other.x, other.y, other.x2, other.y2)
    if this.collisionType == "line":
      if other.collisionType == "circle":
        return geo.intersect_circle_line(other.x, other.y, other.radius, this.x, this.y, this.x2, this.y2)
      if other.collisionType == "aabb":
        return geo.intersect_aabb_line(other.x, other.y, other.w, other.h, this.x, this.y, this.x2, this.y2)
      if other.collisionType == "line":
        return geo.intersect_line(this.x, this.y, this.x2, this.y2, other.x, other.y, other.x2, other.y2)
    return False
  
  # Name chosen to alarm fewer parents.
  def delete(this):
    # This will be used for death animations.
    this.alive = False
  
  # ==========================================
  # Turtle capabilities
  # ==========================================

  # Moves the entity forward by the specified number of pixels.
  def forward(this, amount = 1):
    this.x += math.cos(this.angle / 180 * math.pi) * amount
    this.y += math.sin(this.angle / 180 * math.pi) * amount
  
  # Moves the entity backward by the specified number of pixels.
  # Equivalent to this.forward(-amount)
  def backward(this, amount = 1):
    this.forward(-amount)
  
  # Moves the entity along the vector 90 degrees clockwise of its angle.
  def right(this, amount = 1):
    this.x += math.cos((this.angle + 90) / 180 * math.pi) * amount
    this.y += math.sin((this.angle + 90) / 180 * math.pi) * amount

  # Moves the entity along the vector 90 degrees counter-clockwise of its angle.
  # Equivalent to this.right(-amount)
  def left(this, amount = 1):
    this.right(-amount)

  # Rotates clockwise by the specified number of degrees. (90 by default)
  def rotate(this, amount = 90):
    this.angle += amount
    angle = this.angle / 180 * math.pi
    this.cos = math.cos(angle)
    this.sin = math.sin(angle)

  # Rotates clockwise by the specified number of degrees. (90 by default)
  def turnRight(this, amount = 90):
    this.rotate(amount)
  
  # Rotates counter-clockwise by the specified number of degrees. (90 by default)
  # Equivalent to this.turnRight(-amount)
  def turnLeft(this, amount = 90):
    this.rotate(-amount)

  # Moves an entity by the offset vector
  # Positive y moves the entity forward
  # Positive x moves the entity right
  def move(this, offset = (0, 0)):
    cos = math.cos(this.angle / 180 * math.pi)
    sin = math.sin(this.angle / 180 * math.pi)
    # Forward movement
    this.x += cos * offset[1]
    this.y += sin * offset[1]
    # Lateral movement
    this.x -= sin * offset[0]
    this.y += cos * offset[0]
