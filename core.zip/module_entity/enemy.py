from core.module_entity.entity import entity
from core.globals import images

class enemy(entity):
  # Entity type used to distinguish subclasses
  type = "enemy_base"
  boost_decay = 5000

  def __init__(this, x, y, angle = 90, radius = 32, speed = 200, boost = 1000):
    entity.__init__(this, "enemy", x, y, angle, 128/512)
    this.sprite = images["enemy_base"]
    this.health = 100
    this.radius = radius
    this.speed = speed
    this.boost = boost
    this.update_graphics()
  
  def update(this, dt):
    entity.update(this, dt)
    this.forward((this.speed + this.boost) * dt)
    if this.boost < 0:
      this.boost = 0
    else:
      this.boost -= enemy.boost_decay * dt
