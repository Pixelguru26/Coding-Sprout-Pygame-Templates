import math, pygame
import pygame.draw as __g

# Dummy class to construct a general storage singleton
class __libclass:
  pass
__lib = __libclass()
__lib.surface = None

# Safely retrieves the rendering surface for the graphics library.
# If the surface cannot be retrieved, returns None
def check():
  if __lib.surface == None:
    temp = None
    try:
      temp = pygame.display.get_surface()
    except:
      print("The display surface was unable to be retrieved.")
      return None
    else:
      __lib.surface = temp
  return __lib.surface

def blit(image, x, y):
  surf = check()
  if surf == None: return
  surf.blit(image, (x, y))

def blit_centered(image, x, y):
  surf = check()
  if surf == None: return
  cx = x - image.get_width()/2
  cy = y - image.get_height()/2
  surf.blit(image, (cx, cy))

# Produces a transformed image and draws it to the current surface on the fly, without caching.
# The transformed surface is returned after drawing.
def draw(image, x, y, scale = 1, angle = 0):
  # Ensure a surface exists to draw to
  surf = check()
  if surf == None: return
  # Pick an optimal level of transformation to avoid unnecessary work
  ret = None
  if angle != 0:
    ret = pygame.transform.rotozoom(image, -angle, scale)
  elif scale != 1:
    ret = pygame.transform.scale_by(image, scale)
  else:
    ret = image
  # Image finally rendered with center point at (x, y)
  x = x - ret.get_width()/2
  y = y - ret.get_height() / 2
  surf.blit(ret, (x, y))
  return ret

# Tiles an image across a rectangle on the current surface.
def tile(image, x, y, w, h):
  surf = check()
  if surf == None: return
  oldclip = surf.get_clip()
  surf.set_clip(pygame.rect.Rect(x, y, w, h))
  for iy in range(y,y+h,image.get_height()):
    for ix in range(x, x+w, image.getWidth()):
      surf.blit(image, (ix, iy))
  surf.set_clip(oldclip)

def laser(image, x1, y1, x2, y2):
  pass

def roundedrect(color, x, y, w, h, radius):
  surf = check()
  if surf == None: return
  __g.rect(surf, color, (x+radius, y, w-radius*2, h), 0, radius)
  # __g.arc(surf, color, (x, y, radius, radius), -math.pi/2, 0, radius)
