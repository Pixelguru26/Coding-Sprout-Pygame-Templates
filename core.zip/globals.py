# This object stores global settings for the game's runtime
settings = {}
# Eventually this will be used to disable expensive features and visual effects for better performance
settings["lightmode"] = False
settings["clearscreen"] = True

# Assets are stored in these dictionaries.
images = {}

# Game world objects are stored in these lists.
entities = []
bullets = []